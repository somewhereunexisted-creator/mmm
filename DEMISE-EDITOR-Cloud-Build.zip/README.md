# DEMISE EDITOR — Android Studio project

Aplikasi WebView offline yang membawa editor dictionary dari website ke Android.

## Membuat APK
1. Install Android Studio terbaru.
2. Open folder `demise-editor-android`.
3. Tunggu Gradle Sync dan instal Android SDK API 35 jika diminta.
4. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. APK debug berada di `app/build/outputs/apk/debug/app-debug.apk`.

Nama: DEMISE EDITOR  
Application ID: `com.lexifind.app`  
Minimum: Android 10 (API 29)  
Offline: Ya. File JSON diproses lokal; ekspor disimpan di folder Download.

Catatan: ZIP ini berisi source project Android Studio, bukan APK yang sudah dikompilasi.
